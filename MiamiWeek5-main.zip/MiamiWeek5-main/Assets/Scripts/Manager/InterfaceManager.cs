using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class InterfaceManager : MonoBehaviour
{
    [SerializeField]
    private Button joinPlayerOne;

    //TODO: Add PlayerTwoButton reference
    [SerializeField]
    private Button joinPlayerTwo;

    [SerializeField]
    private Text p1Text;

    [SerializeField]
    private Text p2Text;


    private int jim = 0;
    private int bob = 0;

    [SerializeField]
    private SplitKeyboardPlayerInputManager playerInputManager;
    // Start is called before the first frame update
    void Start()
    {
        joinPlayerOne.onClick.AddListener(() => JoinPlayerOne());
        //TODO Listen for player two click event

        joinPlayerTwo.onClick.AddListener(() => JoinPlayerTwo());
    }

    private void JoinPlayerOne()
    {
        /*  if(jim == 0)
          {

              playerInputManager.JoinPlayer(0, "Keyboard&Mouse");
              p1Text.text = "Leave Player One";
              Debug.Log("Player has Joined");
              jim = 1;
          } else if (jim == 2)
          {
              playerInputManager.VisChar(0);
              jim = 1;
          } else
          {
              Debug.Log("Player has Left");
              playerInputManager.LeavePlayer(0);
              p1Text.text = "Join Player One";
              jim = 2;
          }*/


        if (jim == 0)
        {

            playerInputManager.JoinPlayer(0, "Keyboard&Mouse");
            p1Text.text = "Leave Player One";
            Debug.Log("Player has Joined");
            jim = 1;
        }
        else if (jim == 1)
        {
            Debug.Log("Player has Left");
            playerInputManager.LeavePlayer(0);
            p1Text.text = "Join Player One";
            jim = 0;
        }
  

    }

    private void JoinPlayerTwo()
    {
        /* if (bob == 0)
         {

             playerInputManager.JoinPlayer(1, "PlayerTwo");
             p2Text.text = "Leave Player Two";
             bob = 1;
         }
         else if (bob == 2)
         {
             playerInputManager.VisChar(1);
             bob = 1;
         }
         else
         {
             playerInputManager.LeavePlayer(1);
             p2Text.text = "Join Player Two";
             bob = 2;
         }*/

        if (bob == 0)
        {

            playerInputManager.JoinPlayer(1, "PlayerTwo");
            p2Text.text = "Leave Player Two";
            Debug.Log("Player has Joined");
            bob = 1;
        }
        else if (bob == 1)
        {
            Debug.Log("Player has Left");
            playerInputManager.LeavePlayer(1);
            p2Text.text = "Join Player Two";
            bob = 0;
        }

    }

    
    //TODO Invoke JoinPlayer passing a playerIndex value and targeting a control scheme
    //TODO flip text after player has joined to say "Leave Player Two"
    //TODO on click after player has joined, remove player
}
